


    ___           _ _         ___                           
   /   \_____   _(_| |___    / _ \__ _ _ __ __ _  __ _  ___ 
  / /\ / _ \ \ / | | / __|  / /_\/ _` | '__/ _` |/ _` |/ _ \
 / /_/|  __/\ V /| | \__ \ / /_\| (_| | | | (_| | (_| |  __/
/___,' \___| \_/ |_|_|___/ \____/\__,_|_|  \__,_|\__, |\___|
                                                 |___/      

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

The Devil's Garage 2D Pixel Art - Isometric Blocks - Free Sprites - is a large collection of Isometric Block Pack contains around 700  free game assets. Images are exported at high resolution, and low resolutions

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


License

https://creativecommons.org/licenses/by/4.0/

Attribution 4.0 International (CC BY 4.0)
You are free to:
Share � copy and redistribute the material in any medium or format
Adapt � remix, transform, and build upon the material
for any purpose, even commercially.

Under the following terms:
Attribution � You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

No additional restrictions � You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Attribution - 

Ajay Karat | Devil's Garage
https://devilsgarage.itch.io

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


Please leave a review, If you like these assets, or have a specific art asset need.

Ajay Karat
Devil's Garage 
help@devilsgarage.com

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

http://www.devilsgarage.com
http://twitter.com/devilsgarage 

