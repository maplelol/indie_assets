import { app } from "../core/app";
import * as core from "../core";
import * as game_trigger from "./trigger";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Launch extends cc.Component {

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        app.triggerMgr.regist(new game_trigger.TriggerGameLaunched());
    }

    start () {
        let e = new core.trigger.TriggerEvent();
        e.name = core.trigger.defaultTriggerEventName.game_launched;
        e.object = this;
        app.triggerMgr.fire(e);
    }

    // update (dt) {}
}
