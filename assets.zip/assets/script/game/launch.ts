
import * as etec from "../core";
import * as game_trigger from "./trigger";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Launch extends cc.Component {

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        etec.app.triggerMgr.regist(new game_trigger.TriggerGameLaunched());
    }

    start () {
        let e = new etec.trigger.TriggerEvent();
        e.name = etec.trigger.defaultTriggerEventName.game_launched;
        e.object = this;
        etec.app.triggerMgr.fire(e);
    }

    // update (dt) {}
}
