
import * as core from "../../core"

const {ccclass, property} = cc._decorator;

@ccclass
export default class MainUI extends core.view.ViewBase {

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {
        this.open();
    }

    // update (dt) {}

    
    protected async loadDependency() {

    }

    protected async willOpen() {

    }

    protected onOpened() {

    }

    protected async willClose() {

    }

    protected onClosed() {

    }
}
