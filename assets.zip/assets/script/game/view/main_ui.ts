
import * as etec from "../../core"

const {ccclass, property} = cc._decorator;

@ccclass
export default class MainUI extends etec.view.ViewBase {

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start () {}

    // update (dt) {}

    protected async willOpen() {

    }

    protected onOpened() {

    }

    protected async willClose() {

    }

    protected onClosed() {

    }
}
