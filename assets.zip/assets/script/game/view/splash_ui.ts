
import * as etec from "../../core"

const {ccclass, property} = cc._decorator;

@ccclass
export default class SplashUI extends etec.view.ViewBase {
    protected willOpen() {
    }
    protected onOpened() {
    }
    protected willClose() {
    }
    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {

    }

    // update (dt) {}
}
