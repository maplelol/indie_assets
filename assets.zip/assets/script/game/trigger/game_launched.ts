
import * as etec from "../../core";

export class TriggerGameLaunched extends etec.trigger.TriggerBase {
    constructor() {
        super([etec.trigger.defaultTriggerEventName.game_launched]);
    }

    checkCondition(e:etec.trigger.TriggerEvent): boolean {
        if (e.name == etec.trigger.defaultTriggerEventName.game_launched) {
            return true;
        }
        
        return false;
    }
    
    protected async _onEvent_game_launched(e:etec.trigger.TriggerEvent) {
        console.log("TriggerGameLaunched:onEvent_game_launched");

        etec.app.viewMgr.setup();

        await etec.app.viewMgr.openView("splash/prefab/root");
        
        (e.object as cc.Component).scheduleOnce(()=>{
            etec.app.viewMgr.closeView("splash/prefab/root");
            etec.app.resMgr.dumpRes();
        },1);

        (e.object as cc.Component).scheduleOnce(()=>{
            this.showLoading();
        },3);
    }

    async showLoading() {
        etec.app.viewMgr.openView("loading/prefab/root");
        console.log("2");
        etec.app.resMgr.dumpRes();
        etec.app.resMgr.releaseRes("splash/prefab/root");
        console.log("3");
        etec.app.resMgr.dumpRes();
    }
}
