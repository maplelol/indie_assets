
import * as etec from "../../core";

export class TriggerGameLaunched extends etec.trigger.TriggerBase {
    constructor() {
        super([etec.trigger.defaultTriggerEventName.game_launched]);
    }

    checkCondition(e:etec.trigger.TriggerEvent): boolean {
        if (e.name == etec.trigger.defaultTriggerEventName.game_launched) {
            return true;
        }
        
        return false;
    }
    
    protected async _onEvent_game_launched(e:etec.trigger.TriggerEvent) {
        console.log("TriggerGameLaunched:onEvent_game_launched");

        await etec.app.resMgr.loadRes("splash/prefab/root");
        let prefab = etec.app.resMgr.getRes("splash/prefab/root");
        let nodeSplash:cc.Node = cc.instantiate(prefab);
        cc.director.getScene().addChild(nodeSplash);

        let deps = etec.app.resMgr.getResDepends("splash/prefab/root");
        console.log("deps=[");
        deps.forEach(d=>{
            console.log("   "+d);
        });
        console.log("]");
        
        (e.object as cc.Component).scheduleOnce(()=>{
            nodeSplash.destroy();
            console.log("1");
            etec.app.resMgr.dumpRes();
        },1);

        (e.object as cc.Component).scheduleOnce(()=>{
            this.showLoading();
        },3);
    }

    async showLoading() {
        await etec.app.resMgr.loadResDir("loading/prefab/root");
        cc.director.getScene().addChild(cc.instantiate(etec.app.resMgr.getRes("loading/prefab/root")));
        console.log("2");
        etec.app.resMgr.dumpRes();
        etec.app.resMgr.releaseRes("splash/prefab/root");
        console.log("3");
        etec.app.resMgr.dumpRes();
    }
}
