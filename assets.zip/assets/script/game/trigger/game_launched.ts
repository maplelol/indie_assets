
import * as core from "../../core";
import { app } from "../../core/app";

export class TriggerGameLaunched extends core.trigger.TriggerBase {
    constructor() {
        super([core.trigger.defaultTriggerEventName.game_launched]);
    }

    checkCondition(e:core.trigger.TriggerEvent): boolean {
        if (e.name == core.trigger.defaultTriggerEventName.game_launched) {
            return true;
        }
        
        return false;
    }
    
    protected async _onEvent_game_launched(e:core.trigger.TriggerEvent) {
        console.log("TriggerGameLaunched:onEvent_game_launched");

        await app.resMgr.loadResDir("splash/texture");
        await app.resMgr.loadResDir("splash/prefab");
        cc.director.getScene().addChild(cc.instantiate(app.resMgr.getRes("splash/prefab/root")));

        (e.object as cc.Component).scheduleOnce(()=>{
            this.showLoading();
        },3);
    }

    async showLoading() {
        await app.resMgr.loadResDir("loading/texture");
        await app.resMgr.loadResDir("loading/prefab");
        cc.director.getScene().addChild(cc.instantiate(app.resMgr.getRes("loading/prefab/root")));
    }
}
