
async function waitForSec(sec) {
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve();
        },sec*1000);
    });
}

export class ResManager {
    static readonly instance:ResManager = new ResManager();

    private constructor() {

    }

    async loadRes(url:string,cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        return new Promise((resolve,reject)=>{
            cc.loader.loadRes(url,cbProgress,(error:Error,res:any)=>{
                if (error) {
                    console.warn("ResManager:loadRes:failed:error="+error.message);
                    reject(error);
                } else {
                    resolve(res);
                }
            });
        });
    }

    async loadResArray(urls:string[],cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        return new Promise((resolve,reject)=>{
            cc.loader.loadResArray(urls,cbProgress,(error:Error,res:any[])=>{
                if (error) {
                    console.warn("ResManager:loadResArray:failed:error="+error.message);
                    reject(error);
                } else {
                    resolve(res);
                }
            });
        });
    }

    async loadResDir(url:string,cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        await waitForSec(0.01);
        return new Promise((resolve,reject)=>{
            cc.loader.loadResDir(url,(error:Error,res:any[],urls:string[])=>{
                if (error) {
                    console.warn("ResManager:loadResDir:failed:error="+error.message);
                    reject(error);
                } else {
                    resolve({res:res,urls:urls});
                }
            });
        });
    }

    getRes(url:string) {
        return cc.loader.getRes(url);
    }

    releaseRes(res:any) {
        cc.loader.releaseRes(res);
    }

    releaseResDir(url:string) {
        cc.loader.releaseResDir(url);
    }
}
