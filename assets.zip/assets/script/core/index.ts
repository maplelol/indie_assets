
import * as view from "./view";
import * as trigger from "./trigger";

export {
    view,
    trigger
}
