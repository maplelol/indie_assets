import { ResManager } from "../cocos/res_manager";
import { ViewBase } from "./view_base";

export class ViewManager {
    static readonly instance:ViewManager = new ViewManager();

    private _nodeRoot:cc.Node = undefined;

    setup() {
        this._nodeRoot = cc.director.getScene().getChildByName("Canvas");
    }

    /**
     * 打开一个view
     * @param url 
     * @param params 
     */
    async openView(url:string,...params) {
        /** 加载资源 */
        try {
            await ResManager.instance.loadRes(url);
        } catch(e) {
            console.error(`ViewManager:openView:error:${url}:loadRes failed`);
            return Promise.reject();
        }
        
        /** 实例化资源并添加到场景 */
        let prefab:cc.Prefab = ResManager.instance.getRes(url);
        let node:cc.Node = cc.instantiate(prefab);
        this._nodeRoot.addChild(node);
        let view:ViewBase = node.getComponent(ViewBase);
        if (!view) {
            console.error(`ViewManager:openView:error:${url}:is not a ViewBase`);
            return Promise.reject();
        }

        view.url = url;
        await view.open(...params);

        return Promise.resolve(view);
    }

    /**
     * 查找一个view
     * @param url 
     */
    getView(url:string) {
        let view:ViewBase = undefined;
        for (let i=0; i<this._nodeRoot.children.length; ++i) {
            view = this._nodeRoot.children[i].getComponent(ViewBase);
            if (view && view.url == url) {
                return view.node;
            }
        }
        return undefined;
    }

    /**
     * 关闭一个view
     * @param url 
     * @param params 
     */
    async closeView(url:string,...params) {
        /** 找到场景中的节点 */
        let node = this.getView(url);
        if (!node) {
            console.warn(`ViewManager:closeView:${url}:no exist view`);
            return Promise.reject();
        }

        /** 关闭并销毁 */
        let view:ViewBase = node.getComponent(ViewBase);
        await view.close(...params);
        node.destroy();

        /** 释放资源的引用计数 */
        ResManager.instance.releaseResRetain(url);
    }

    /**
     * 直接删除一个view
     * @param url 
     */
    removeView(url:string) {
        /** 找到场景中的节点 */
        let node = this.getView(url);
        if (!node) {
            console.warn(`ViewManager:closeView:${url}:no exist view`);
            return;
        }
        
        /** 直接销毁 */
        node.destroy();

        /** 释放资源的引用计数 */
        ResManager.instance.releaseResRetain(url);
    }
}
