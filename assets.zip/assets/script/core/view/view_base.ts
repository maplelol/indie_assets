
let ccNodeBind = cc.Class({
    name:"ccNodeBind",
    properties: {
        node:cc.Node,
        name:""
    },
    ctor: function () {}
});

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("core/view/ViewBase")
export abstract class ViewBase extends cc.Component {
    protected _openParams:any[] = undefined;
    protected _closeParams:any[] = undefined;
    private _url:string = undefined;

    set url(url:string) {
        this._url = url;
    }
    get url() {
        return this._url;
    }

    async open(...params) {
        this._openParams = params;

        await this.willOpen();
        this.onOpened();
    }

    async close(...params) {
        this._closeParams = params;
        await this.willClose();

        this._openParams = undefined;
        this._closeParams = undefined;
        
        this.onClosed();
    }

    /**
     * 将要打开，可以用来进行异步加载依赖的资源、配置等
     * 需要播放打开动画的话在这里播放
     */
    protected abstract async willOpen();
    /**
     * 已经播放完打开动画
     */
    protected abstract onOpened();
    /**
     * 将要关闭
     * 需要播放关闭动画的话在这里播放
     */
    protected abstract async willClose();
    /**
     * 已经关闭
     */
    protected abstract onClosed();
}
