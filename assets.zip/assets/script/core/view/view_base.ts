
let ccNodeBind = cc.Class({
    name:"ccNodeBind",
    properties: {
        node:cc.Node,
        name:""
    },
    ctor: function () {}
});

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("core/view/ViewBase")
export abstract class ViewBase extends cc.Component {
    protected _openParams:any[] = undefined;
    protected _closeParams:any[] = undefined;
    protected _mapBindNode:Map<string,cc.Node> = new Map();

    @property({
        type: [ccNodeBind]
    })
    protected nodeBindList = [];

    async open(...params) {
        this._openParams = params;

        this._mapBindNode.clear();
        this.nodeBindList.forEach(n=>{
            console.log(`${n.name}`);
            this._mapBindNode.set(n.name,n.node);
        });

        await this.loadDependency();
        await this.willOpen();
        this.onOpened();
    }

    async close(...params) {
        this._closeParams = params;
        await this.willClose();

        this._mapBindNode.clear();
        this._openParams = undefined;
        this._closeParams = undefined;
        
        this.onClosed();
    }

    getBindNode(name:string) {
        return this._mapBindNode.get(name);
    }

    protected abstract async loadDependency();
    protected abstract async willOpen();
    protected abstract onOpened();
    protected abstract async willClose();
    protected abstract onClosed();
}
