
/**
 * 分辨率适配策略，绑在场景的Canvas上面
 * 适配策略就是，如果屏幕长宽比<设计长宽比，那么就适配高度，否则适配宽度
 * 比如设计分辨率是750x1334(iphone6/6plus)，那么6/7/8/x都是适配宽度，iPad适配高度
 * 由于不同机型适配策略不同，这样的话，场景原画一般需要在四周多画一些，保证四周不会留黑边，或者是一张可以进行拉伸的底板
 */

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("core/component/ResolutionAdaptor")
export default class ResolutionAdaptor extends cc.Component {
    onLoad() {
        this.setResolution();

        cc.view.setResizeCallback(()=>{
            console.debug("ResolutionAdaptor:cc.view.setResizeCallback");
            this.setResolution();
        });
    }

    public setResolution() {
        let frameSize = cc.view.getFrameSize();
        let width = frameSize.width > frameSize.height ? frameSize.width : frameSize.height;
        let height = frameSize.width > frameSize.height ? frameSize.height : frameSize.width;
        let designSize = cc.view.getDesignResolutionSize();
        let designWidth = designSize.width > designSize.height ? designSize.width : designSize.height;
        let designHeight = designSize.width > designSize.height ? designSize.height : designSize.width;
        if (width/height < designWidth/designHeight) {
            this.getComponent(cc.Canvas).fitHeight = true;
            this.getComponent(cc.Canvas).fitWidth = false;
        } else {
            this.getComponent(cc.Canvas).fitHeight = false;
            this.getComponent(cc.Canvas).fitWidth = true;
        }
    }
}
