
/**
 * 刘海屏屏的适配，主要绑定在需要对齐到屏幕顶端的节点上
 */

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("core/component/ResolutionFringeAdaptor")
export default class ResolutionFringeAdaptor extends cc.Component {
    @property({
        tooltip : "需要向下偏移多少像素"
    })
    private Offset = 40;

    onLoad() {
        if (false) {
            if (this.getComponent(cc.Widget)) {
                this.getComponent(cc.Widget).top += this.Offset;
            } else {
                this.node.y += this.Offset;
            }
        } 
    }
}
