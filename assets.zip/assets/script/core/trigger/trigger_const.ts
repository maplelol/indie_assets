
/**
 * Trigger的优先级组
 */
export enum kTriggerPriority {
    default = 0, //低
    hight = 1, //高
    exclusive = 2, //独占
}

/**
 * 内置的事件名字
 */
export const defaultTriggerEventName = {
    game_launched : "game_launched",
}
