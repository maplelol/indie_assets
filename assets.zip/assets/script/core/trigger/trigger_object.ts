
export class TriggerObject {
    
}
