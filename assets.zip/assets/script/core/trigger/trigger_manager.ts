import { TriggerEvent } from "./trigger_event";
import { TriggerBase } from "./trigger_base";
import { kTriggerPriority } from "./trigger_const";

/**
 * 管理Trigger并分发事件
 */
export class TriggerManger {
    /**
     * 单例
     */
    static readonly instance = new TriggerManger();

    /**
     * 存放每个Trigger对象
     */
    private _mapTrigger:Map<number,TriggerBase> = new Map(); 

    /**
     * //存放的事件表，每个kTriggerPriority一个单独的队列
     */
    private _vTriggerGroup:Array<Map<string,Set<TriggerBase>>> = new Array(); 

    private constructor() {
        this._vTriggerGroup.push(new Map()); //kTriggerPriority.default
        this._vTriggerGroup.push(new Map()); //kTriggerPriority.high
        this._vTriggerGroup.push(new Map()); //kTriggerPriority.exclusive
    }

    /**
     * 按照kTriggerPriority的顺序去遍历并分发事件
     * 如果有高优先级的Trigger组接收了事件，那么会把事件中的swallowed置为true，继续向下分发
     * @param e 
     */
    fire(e:TriggerEvent) {
        for (let i=this._vTriggerGroup.length-1; i>=0; --i) {
            let st = this._vTriggerGroup[i].get(e.name);
            if (st) {
                let swallowed = false;
                st.forEach(t=>{
                    if (t.isValid && t.checkCondition(e)) {
                        t.onEvent(e);
                        swallowed = true;
                    }
                });
                e.swallowed = swallowed;
            }
        }
    }

    /**
     * 注册Trigger
     * @param t 
     */
    regist(t:TriggerBase) {
        if (!this._mapTrigger.get(t.id)) {
            this._mapTrigger.set(t.id,t);
        } 

        let mapEvent = this._vTriggerGroup[t.priority];
        t.registEvents.forEach(e=>{
            let st = mapEvent.get(e);
            if (!st) {
                st = new Set();
                mapEvent.set(e,st);
            }
            if (st.has(t)) {
                console.warn("duplicate regist trigger");
            } else {
                st.add(t);
            }
        });
    }

    /**
     * 删除Trigger
     * 为了避免发生在循环中删除等问题，会先把Trigger的isValid置为false，然后延迟删除
     * @param t 
     */
    remove(t:TriggerBase) {
        this._mapTrigger.delete(t.id);
        
        t.onDestroy();

        // let mapEvent = this._vTriggerGroup[t.priority];
        // t.registEvents.forEach(e=>{
        //     let st = mapEvent.get(e);
        //     if (st) {
        //         st.delete(t);
        //     }
        // });
    }
}
