
import * as trigger from "./trigger"
import { ResManager } from "./cocos/res_manager";

class App {
    private _iLastUpdate:number = undefined;

    constructor() {
        this._iLastUpdate = Date.now();
        
        cc.game.on(cc.game.EVENT_SHOW,this._onShow,this);
        cc.game.on(cc.game.EVENT_HIDE,this._onHide,this);

        cc.director.on(cc.Director.EVENT_BEFORE_UPDATE,this._onUpdate,this);
    }

    get triggerMgr() { return trigger.TriggerManger.instance; }
    get resMgr() { return ResManager.instance; }

    private _onUpdate() {
        let iLast = this._iLastUpdate;
        this._iLastUpdate = Date.now();
        let dt = (this._iLastUpdate - iLast) / 1000;
    }

    private _onShow() {
        console.debug("App:_onShow");
    }

    private _onHide() {
        console.debug("App:_onHide");
    }
}

const app = new App();
export {app};
