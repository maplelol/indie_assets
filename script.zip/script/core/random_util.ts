
export class RandomUtil {
    public static random(n1,n2) {
        if (n1 != null && n2 != null) {
            return n1 + Math.floor(Math.random()*(n2-n1+1));
        }
        else if (n1 != null) {
            return 1 + Math.floor(Math.random()*n1);
        }
        else {
            return 1 + Math.floor(Math.random()*Number.MAX_VALUE);
        }
    }

    public static random_from_array(array) {
        if (array.length == 0) {
            return null;
        } else if (array.length == 1) {
            return array[0];
        } else {
            return array[RandomUtil.random(1,array.length)-1];
        }
    }

    public static random_discrete_distribution(l,cb) {
        let i_sum = 0;
        let tbWeight = {};
        for (var k in l) {
            if (l[k] != null) {
                tbWeight[k] = {low:i_sum};
                i_sum += cb(k,l[k]);
                tbWeight[k].high = i_sum;
            }
        }
        if (i_sum > 0) {
            let i_random = RandomUtil.random(1,Math.floor(i_sum));
            for (var k in tbWeight) {
                if (i_random > tbWeight[k].low && i_random <= tbWeight[k].high) {
                    return k;
                }
            }
        }
        return null;
    }

    public static shuffle_array(arr) {
        if (arr.length > 1) {
            for (let i = 0; i < arr.length; i++) {
                let ia = Math.floor(Math.random()*arr.length);
                let ib = Math.floor(Math.random()*arr.length);

                let va = arr[ia];
                arr[ia] = arr[ib];
                arr[ib] = va;
            }
        }
        return arr;
    }
}
