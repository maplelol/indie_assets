
export class ConfigManager {
    static readonly instance:ConfigManager = new ConfigManager;

    /**
     * 配置查找表
     */
    private _mapConfig:Map<string,Map<number|string,any>> = new Map();
    /**
     * 扩展查找表，比如需要构建逆向查找表的话，就可以存入这个map
     */
    private _mapConfigExt:Map<string,any> = new Map();

    /**
     * 构建成一个由cid作为key的查找表
     * @param configName 
     * @param config 
     */
    public addConfig(configName:string,config:any) {
        if (!this._mapConfig.get(configName)) {
            let newMap = new Map();
            this._mapConfig.set(configName,newMap);

            for(let i=0; i<config.length; ++i) {
                newMap.set(config[i].cid,config[i]);
            }
        } else {
            console.warn("ConfigManager:addConfig:alread exist:"+configName);
        }
    }

    /** 查找配置 */
    public getConfig(configName:string,cid:number|string) {
        return this._mapConfig.get(configName).get(cid);
    }

    /** 遍历某个配置表 */
    public foreachConfig(configName:string,fn:(ket:number|string,value:string)=>void) {
        this._mapConfig.get(configName).forEach((v,k)=>{
            fn(k,v);
        });
    }

    /** 扩展查找表 */
    public addExtConfigMap(configName:string,config:any) {
        this._mapConfigExt.set(configName,config);
    }
    public getExtConfig(configName:string,key?:any) {
        if (key != undefined && key != null) {
            return this._mapConfigExt.get(configName).get(key);
        } else {
            return this._mapConfigExt.get(configName);
        }
    }
}
