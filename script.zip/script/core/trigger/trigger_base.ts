import { kTriggerPriority } from "./trigger_const";
import { TriggerEvent } from "./trigger_event";

/**
 * 触发器
 * 每个触发器需要实现自己的checkCondition和onEvent
 */
export abstract class TriggerBase {
    /**
     * 实例id
     */
    protected _iId:number = -1;
    /**
     * 是否还有效，如果为false的话那么久不会再接收到任何事件了
     */
    protected _isValid:boolean = false;
    /**
     * 所在的优先级组
     */
    protected _iPriority:kTriggerPriority = kTriggerPriority.default;
    /**
     * 注册的事件名字
     */
    protected _setRegistEvent:Set<string> = new Set();

    /**
     * 用来生成实例id
     */
    private static _iAllocId:number = 0;

    /**
     * 监听的事件需要在构造的时候传进来
     * @param eventList 
     */
    constructor(eventList:string[]) {
        this._iId = ++TriggerBase._iAllocId;
        this._isValid = true;

        eventList.forEach(e=>{
            this._setRegistEvent.add(e);
        });
    }

    get id() {
        return this._iId;
    }

    get isValid() {
        return this._isValid;
    }

    get priority() {
        return this._iPriority;
    }

    get registEvents() {
        return this._setRegistEvent;
    }

    onDestroy() {
        this._isValid = false;
    }
    /**
     * 处理事件
     * @param e 
     */
    abstract onEvent(e:TriggerEvent);
}
