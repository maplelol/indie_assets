
/**
 * 触发事件，可以携带触发对象和触发数据
 */
export class TriggerEvent {
    /**
     * 事件名字
     */
    name:string = undefined;
    /**
     * 触发对象
     */
    object:any = undefined;
    /**
     * 触发数据
     */
    data:any = undefined;
    /**
     * 是否已经被高优先级的Trigger处理了
     */
    swallowed:boolean = false;
}
