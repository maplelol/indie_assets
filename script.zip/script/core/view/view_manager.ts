import { ResManager } from "../cocos/res_manager";
import { ViewBase } from "./view_base";
import MaskViewBase from "./mask_view_base";

export enum kViewLayers {
    bottom, //主界面
    middle_mask, //弹窗遮罩
    middle, //弹窗
    top, //菊花或者遮罩
}

export class ViewManager {
    static readonly instance:ViewManager = new ViewManager();

    private _nodeRoot:cc.Node = undefined;

    /** top层会用到的一些节点 */
    private _nodeIndicator:cc.Node = undefined;
    private _nodeMask:cc.Node = undefined;
    private _nodeTransparentMask:cc.Node = undefined;
    private _nodeDialogMask:cc.Node = undefined;

    /**
     * 使用manager之前需要先setup，用于初始化内部的节点层级管理
     * @param indicatorView 菊花
     * @param maskView 遮罩
     */
    setup(indicatorView:cc.Node,maskView:cc.Node) {
        this._nodeRoot = this.newFullScreenLayer("root");
        cc.find("Canvas").addChild(this._nodeRoot);

        /** 创建每一层的根节点 */
        for (let i=kViewLayers.bottom; i<=kViewLayers.top; ++i) {
            let node = this.newFullScreenLayer("view_layer"+i);
            this._nodeRoot.addChild(node);
        }

        /** 半透明遮罩 */
        this._nodeMask = maskView;
        this._nodeMask.active = false;
        this._nodeRoot.children[kViewLayers.top].addChild(this._nodeMask);
        /** 菊花 */
        this._nodeIndicator = indicatorView;
        this._nodeIndicator.active = false;
        this._nodeRoot.children[kViewLayers.top].addChild(this._nodeIndicator);
        /** 透明遮罩 */
        this._nodeTransparentMask = this.newFullScreenLayer("transparent_mask");
        this._nodeTransparentMask.addComponent(cc.BlockInputEvents);
        this._nodeTransparentMask.addComponent(MaskViewBase);
        this._nodeTransparentMask.active = false;
        this._nodeRoot.children[kViewLayers.top].addChild(this._nodeTransparentMask);
        /** 弹窗遮罩 */
        this._nodeDialogMask = cc.instantiate(this._nodeMask);
        this._nodeRoot.children[kViewLayers.middle_mask].addChild(this._nodeDialogMask);
    }

    /**
     * 进入一个新场景
     * @todo 这边切换效果暂时写死了，有需要的话以后可以扩展
     */
    async enterScene() {
        this._nodeRoot.opacity = 0;

        return new Promise((resolve,reject)=>{
            this._nodeRoot.runAction(cc.sequence(
                cc.fadeIn(0.5),
                cc.delayTime(0.3),
                cc.callFunc(()=>{resolve();})
            ));
        });
    }

    /**
     * 退出当前场景
     * @todo 这边切换效果暂时写死了，有需要的话以后可以扩展
     */
    async exitScene() {
        this._nodeRoot.opacity = 255;

        return new Promise((resolve,reject)=>{
            this._nodeRoot.runAction(cc.sequence(
                cc.fadeOut(0.5),
                cc.delayTime(0.3),
                cc.callFunc(()=>{
                    this._removeViewAtLayer(kViewLayers.bottom);
                    this._removeViewAtLayer(kViewLayers.middle);
                    ResManager.instance.releaseUnused();
                    resolve();
                })
            ));
        });
    }

    /**
     * 打开一个view
     * @param url 
     * @param params 
     */
    async openView(url:string,layer:kViewLayers,...params) {
        /** 加载资源 */
        try {
            await ResManager.instance.loadRes(url);
        } catch(e) {
            console.error(`ViewManager:openView:error:${url}:loadRes failed`);
            return Promise.reject();
        }
        
        /** 实例化资源并添加到场景 */
        let prefab:cc.Prefab = ResManager.instance.getRes(url);
        let node:cc.Node = cc.instantiate(prefab);
        let view:ViewBase = node.getComponent(ViewBase);
        if (!view) {
            console.error(`ViewManager:openView:error:${url}:is not a ViewBase`);
            return Promise.reject();
        }

        view.resUrl = url;

        return this.addView(view,layer,...params);
    }

    async addView(view:ViewBase,layer:kViewLayers,...params) {
        this._nodeRoot.children[layer].addChild(view.node);

        this.showTransparentMaskView(true);
        await view.open(...params);
        this.showTransparentMaskView(false);

        return Promise.resolve(view);
    }

    /**
     * 关闭一个view
     * @param url 
     * @param params 
     */
    async closeView(url:string,...params) {
        /** 找到场景中的节点 */
        let node = this.getView(url);
        if (!node) {
            console.warn(`ViewManager:closeView:${url}:no exist view`);
            return Promise.reject();
        }

        /** 关闭并销毁 */
        let view:ViewBase = node.getComponent(ViewBase);
        this.showTransparentMaskView(true);
        await view.close(...params);
        this.showTransparentMaskView(false);
        node.destroy();

        /** 释放资源的引用计数 */
        ResManager.instance.releaseResRetain(url);
        ResManager.instance.releaseUnused();
    }

    /**
     * 打开一个主界面
     * @param url 
     * @param params 
     */
    async openMainUI(url:string,...params) {
        return this.openView(url,kViewLayers.bottom,...params);
    }

    /**
     * 打开一个弹窗，同时还会在UI下面叠一个黑色遮罩
     * @param url 
     * @param params 
     */
    async openDialog(url:string,...params) {
        this._nodeDialogMask.getComponent(MaskViewBase).syncOpen();
        this.openView(url,kViewLayers.middle,...params);
    }

    /**
     * 关闭一个弹窗，同时关闭之前打开的黑色遮罩
     * @param url 
     * @param params 
     */
    async closeDialog(url:string,...params) {
        await this.closeView(url,...params);
        this._nodeDialogMask.getComponent(MaskViewBase).syncClose();
    }

    /**
     * 查找一个view
     * @param url 
     */
    getView(url:string) {
        let view:ViewBase = undefined;
        for (let i=0; i<this._nodeRoot.childrenCount; ++i) {
            let nodeLayer = this._nodeRoot.children[i];
            for (let j=0; j<nodeLayer.children.length; ++j) {
                view =nodeLayer.children[j].getComponent(ViewBase);
                if (view && view.resUrl == url) {
                    return view.node;
                }
            }
        }
        return undefined;
    }

    /**
     * 直接删除一个view
     * @param url 
     */
    removeView(url:string) {
        /** 找到场景中的节点 */
        let node = this.getView(url);
        if (!node) {
            console.warn(`ViewManager:closeView:${url}:no exist view`);
            return;
        }
        
        /** 直接销毁 */
        node.destroy();

        /** 释放资源的引用计数 */
        ResManager.instance.releaseResRetain(url);
        ResManager.instance.releaseUnused();
    }

    /**
     * 显示或打开菊花
     * @param show 
     */
    showIndicatorView(show:boolean) {
        if (show) {
            this._nodeIndicator.getComponent(MaskViewBase).syncOpen();
        } else {
            this._nodeIndicator.getComponent(MaskViewBase).syncClose();
        }
    }

    /**
     * 显示或打开半透明遮罩
     * @param show 
     */
    showMaskView(show:boolean) {
        if (show) {
            this._nodeMask.getComponent(MaskViewBase).syncOpen();
        } else {
            this._nodeMask.getComponent(MaskViewBase).syncClose();
        }
    }

    /**
     * 显示或打开透明遮罩
     * @param show 
     */
    showTransparentMaskView(show:boolean) {
        if (show) {
            this._nodeTransparentMask.getComponent(MaskViewBase).syncOpen();
        } else {
            this._nodeTransparentMask.getComponent(MaskViewBase).syncClose();
        }
    }

    /**
     * 创建一个全屏大小的节点，作为容器
     * @param name 名字一定要传，不然调试的时候就搞不清楚了
     */
    newFullScreenLayer(name:string) {
        let node = new cc.Node();
        node.name = name;
        node.anchorX = 0.5;node.anchorY = 0.5;
        let w = node.addComponent(cc.Widget);
        w.top = 0;w.bottom = 0;w.left = 0;w.right = 0;
        w.isAlignTop = true;w.isAlignBottom = true;w.isAlignLeft = true;w.isAlignRight = true;
        return node;
    }

    /**
     * 把某一层下的所有节点全销毁，同时释放资源的引用计数
     * @param layer 
     */
    private _removeViewAtLayer(layer:kViewLayers) {
        let nodeLayer = this._nodeRoot.children[layer];
        nodeLayer.children.forEach(c=>{
            let v = c.getComponent(ViewBase);
            ResManager.instance.releaseResRetain(v.resUrl);
        });
        nodeLayer.destroyAllChildren();
    }
}
