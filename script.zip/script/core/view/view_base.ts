import { TriggerEvent } from "../trigger/trigger_event";
import { defaultTriggerEventName } from "../trigger/trigger_const";
import { TriggerManger } from "../trigger/trigger_manager";

// let ccNodeBind = cc.Class({
//     name:"ccNodeBind",
//     properties: {
//         node:cc.Node,
//         name:""
//     },
//     ctor: function() {}
// });

const {ccclass, property} = cc._decorator;

@ccclass
export abstract class ViewBase extends cc.Component {
    protected _openParams:any[] = undefined;
    protected _closeParams:any[] = undefined;
    private _resUrl:string = undefined;

    onDestroy() {
        this._openParams = undefined;
        this._closeParams = undefined;
    }

    set resUrl(url:string) {
        this._resUrl = url;
    }
    get resUrl() {
        return this._resUrl;
    }

    async open(...params) {
        this._openParams = params;

        await this.willOpen();
        this.onOpened();
        
        this._openParams = undefined;
    }

    async close(...params) {
        this._closeParams = params;
        await this.willClose();

        this._openParams = undefined;
        this._closeParams = undefined;
        
        this.onClosed();
    }
    protected _bindFireClickBtn(btn:cc.Node) {
        btn.on(cc.Node.EventType.TOUCH_END,()=>{this._fireClickBtn(btn)});
    }


    /**
     * 把按钮的点击事件发送出去，由controller来处理
     * @param btn 
     */
    protected _fireClickBtn(btn:cc.Node|string) {
        let e = new TriggerEvent();
        e.name = defaultTriggerEventName.ui_btn_clicked;
        e.object = this;
        e.data = btn;
        TriggerManger.instance.fire(e);
    }

    /**
     * 将要打开，可以用来进行异步加载依赖的资源、配置等
     * 需要播放打开动画的话在这里播放
     */
    protected abstract async willOpen();
    /**
     * 已经播放完打开动画
     */
    protected abstract onOpened();
    /**
     * 将要关闭
     * 需要播放关闭动画的话在这里播放
     */
    protected abstract async willClose();
    /**
     * 已经关闭
     */
    protected abstract onClosed();
}
