import { ViewBase } from "./view_base";

const {ccclass, property} = cc._decorator;

@ccclass
export default class MaskViewBase extends ViewBase {
    protected _iLayers:number = 0;
    
    /** 提供同步的打开和关闭接口 */
    syncOpen() {
        ++this._iLayers;
        if (this._iLayers == 1) {
            this.node.active = true;
            this.onOpened();
        }
    }

    syncClose() {
        --this._iLayers;
        if (this._iLayers == 0) {
            this.node.active = false;
            this.onClosed();
        }
        this._iLayers = Math.max(0,this._iLayers);
    }

    reset() {
        if (this._iLayers > 0) {
            this.onClosed();
        }
        this._iLayers = 0;
        this.node.active = false;
    }

    protected async willOpen() {}
    protected onOpened() {}
    protected async willClose() {}
    protected onClosed() {}

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start () {}

    // update (dt) {}
}
