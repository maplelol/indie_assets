
async function waitForSec(sec) {
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve();
        },sec*1000);
    });
}

class ResRetain {
    url:string = "";
    count:number = 0;
}

/**
 * 资源管理
 * 资源加载的过程均为异步
 * 每个资源被加载时，会去获取它的所有依赖，将所有依赖的引用计数+1
 * 每个资源被释放时，也会去获取它的所有依赖，并将依赖的引用计数-1，如果引用计数为0了，则进行释放
 */
export class ResManager {
    static readonly instance:ResManager = new ResManager();
    
    /**
     * 资源引用计数查找表，key=resKey
     */
    private _mapResRetain:Map<string,ResRetain> = new Map();

    private constructor() {

    }

    async loadRes(url:string,cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        return new Promise((resolve,reject)=>{
            cc.loader.loadRes(url,cbProgress,(error:Error,res:any)=>{
                if (error) {
                    console.warn("ResManager:loadRes:failed:error="+error.message);
                    reject(error);
                } else {
                    this._addResDepends(url,res);
                    resolve(res);
                }
            });
        });
    }

    async loadResArray(urls:string[],cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        return new Promise((resolve,reject)=>{
            cc.loader.loadResArray(urls,cbProgress,(error:Error,res:any[])=>{
                if (error) {
                    console.warn("ResManager:loadResArray:failed:error="+error.message);
                    reject(error);
                } else {
                    for (let i=0; i<res.length; ++i) {
                        this._addResDepends(urls[i],res[i]);
                    }
                    resolve(res);
                }
            });
        });
    }

    async loadResAtlas(url:string,cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        return new Promise((resolve,reject)=>{
            cc.loader.loadRes(url,cc.SpriteAtlas,cbProgress,(error:Error,res:any)=>{
                if (error) {
                    console.warn("ResManager:loadResAtlas:failed:error="+error.message);
                    reject(error);
                } else {
                    this._addResDepends(url,res);
                    resolve(res);
                }
            });
        });
    }

    /**
     * @param url 
     * @param cbProgress 
     */
    async loadResDir(url:string,cbProgress?:(completedCount:number,totalCount:number,item:any)=>void) {
        /**
         * TODO:不知道为什么同一帧调用两次cc.loader.loadResDir会造成堆栈溢出，这里先临时这样处理下
         */
        await waitForSec(0.01);
        return new Promise((resolve,reject)=>{
            cc.loader.loadResDir(url,cbProgress,(error:Error,res:any[],urls:string[])=>{
                if (error) {
                    console.warn("ResManager:loadResDir:failed:error="+error.message);
                    reject(error);
                } else {
                    for (let i=0; i<res.length; ++i) {
                        this._addResDepends(urls[i],res[i]);
                    }
                    resolve({res:res,urls:urls});
                }
            });
        });
    }

    /**
     * 同步获取一个已经加载到内存的资源
     * @param url 
     */
    getRes(url:string,type?:Function) {
        return cc.loader.getRes(url,type);
    }

    /**
     * 获取图集中的某个精灵帧
     * @param atlasUrl 
     * @param frame 
     */
    getAtlasFrame(atlasUrl:string,frame:string) {
        let atlas:cc.SpriteAtlas = cc.loader.getRes(atlasUrl);
        if (!atlas) {
            console.warn(`ResManager:getAtlasFrame:${atlasUrl}:${frame}:failed`);
        }
        return atlas.getSpriteFrame(frame);
    }

    /**
     * 获取某个资源所有的依赖项
     * @param res 
     */
    getResDepends(res:any) {
        return cc.loader.getDependsRecursively(res);
    }
    
    /**
     * 释放引用计数
     * @param res 
     */
    releaseResRetain(res:cc.Asset|cc.RawAsset|string) {
        let deps = this.getResDepends(res);
        deps.forEach(d=>{
            let c = this._mapResRetain.get(d);
            if (c && c.count > 0) {
                --c.count;
            } else {
                console.warn(`ResManager:releaseResRetain:${d}:no retain info`);
            }
        });
    }

    /**
     * 释放某个资源，包括它所有的依赖项
     * @param res 
     */
    releaseRes(res:cc.Asset|cc.RawAsset|string) {
        let deps = this.getResDepends(res);
        deps.forEach(d=>{
            this._releaseRes(d);
        });
    }

    /**
     * 释放所有引用计数为0的资源
     */
    releaseUnused() {
        let tmp = {};
        this._mapResRetain.forEach((v,k)=>{
            if (v.count <= 0) {
                tmp[k] = v;
                //console.log(`ResManager:releaseUnused:${v.url}:${k}`);
                cc.loader.release(k);
            }
        });
        for (let k in tmp) {
            this._mapResRetain.delete(k);
        }
    }

    /**
     * 释放所有资源
     */
    releaseAll() {
        this._mapResRetain.clear();
        cc.loader.releaseAll();
    }

    /**
     * 打印输出当前的资源使用
     */
    dumpRes() {
        this._mapResRetain.forEach((v,k)=>{
            console.log(`ResManager:dumpRes:${v.url}:${v.count}:${k}`);
        });
    }

    private _addResDepends(url:string,res:cc.Asset) {
        let deps = this.getResDepends(res);
        deps.forEach(d=>{
            let c = this._mapResRetain.get(d);
            if (!c) {
                c = new ResRetain();
                c.url = url;
                c.count = 0;
                this._mapResRetain.set(d,c);
            }
            ++c.count;
        });
    }

    private _releaseRes(resKey:string) {
        let c = this._mapResRetain.get(resKey);
        if (c) {
            --c.count;
            if (c.count <= 0) {
                this._mapResRetain.delete(resKey);
                //console.log(`ResManager:_releaseRes:${c.url}:${resKey}`);
                cc.loader.release(resKey);
            }
        }
    }
}
