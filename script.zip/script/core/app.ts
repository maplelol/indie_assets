
import { ResManager } from "./cocos/res_manager";
import { TriggerManger } from "./trigger/trigger_manager";
import { ViewManager } from "./view/view_manager";
import { ConfigManager } from "./config_manager";

class App {
    private _iLastUpdate:number = undefined;

    constructor() {
        this._iLastUpdate = Date.now();
        
        cc.game.on(cc.game.EVENT_SHOW,this._onShow,this);
        cc.game.on(cc.game.EVENT_HIDE,this._onHide,this);

        cc.director.on(cc.Director.EVENT_BEFORE_UPDATE,this._onUpdate,this);
    }

    get triggerMgr() { return TriggerManger.instance; }
    get resMgr() { return ResManager.instance; }
    get viewMgr() { return ViewManager.instance; }
    get configMgr() { return ConfigManager.instance; }

    private _onUpdate() {
        let iLast = this._iLastUpdate;
        this._iLastUpdate = Date.now();
        let dt = (this._iLastUpdate - iLast) / 1000;
    }

    private _onShow() {
        console.debug("App:_onShow");
    }

    private _onHide() {
        console.debug("App:_onHide");
    }
}

const app = new App();
export {app};
