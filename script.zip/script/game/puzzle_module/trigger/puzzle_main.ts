
import { TriggerBase } from "../../../core/trigger/trigger_base";
import { defaultTriggerEventName } from "../../../core/trigger/trigger_const";
import { TriggerEvent } from "../../../core/trigger/trigger_event";
import { app } from "../../../core/app";
import PuzzleMainUI from "../view/puzzle_main_ui";
import PuzzleExitUI from "../view/puzzle_exit_ui";
import { gameTriggerEventName } from "../../base/model/trigger_def";
import { gameConfigName, levelConfigPath } from "../../base/model/config_def";

export default class TriggerPuzzleMain extends TriggerBase {
    constructor() {
        super([defaultTriggerEventName.ui_btn_clicked,gameTriggerEventName.enter_puzzle]);
    }

    onEvent(e:TriggerEvent) {
        if (e.name == defaultTriggerEventName.ui_btn_clicked) {
            if (e.object instanceof PuzzleMainUI) {
                return this._onEvent_BtnClick_PuzzleMainUI(e);
            } else if (e.object instanceof PuzzleExitUI) {
                return this._onEvent_BtnClick_PuzzleExitUI(e);
            }
        } else if (e.name == gameTriggerEventName.enter_puzzle) {
            return this._onEvent_EnterPuzzle(e);
        }
        return false;
    }

    private _onEvent_BtnClick_PuzzleMainUI(e:TriggerEvent) {
        let puzzleMainUI = e.object as PuzzleMainUI;
        if (e.data == puzzleMainUI.btnExit) {
            app.viewMgr.openDialog(PuzzleExitUI.url);
            return true;
        }

        return false;
    }

    private _onEvent_BtnClick_PuzzleExitUI(e:TriggerEvent) {
        let puzzleExitUI = e.object as PuzzleExitUI;
        if (e.data == puzzleExitUI.btnClose) {
            app.viewMgr.closeDialog(PuzzleExitUI.url);
            return true;
        } else if (e.data == puzzleExitUI.btnExit) {
            this._onBtn_PuzzleExitUI_Exit();
            return true;
        } else if (e.data == puzzleExitUI.btnContinue) {
            app.viewMgr.closeDialog(PuzzleExitUI.url);
            return true;
        } else if (e.data == puzzleExitUI.btnRestart) {
            app.viewMgr.closeDialog(PuzzleExitUI.url);
            this._enterPuzzleScene();
            return true;
        }

        return false;
    }

    private async _onBtn_PuzzleExitUI_Exit() {
        await app.viewMgr.closeDialog(PuzzleExitUI.url);
        
        let eExitPuzzle = new TriggerEvent();
        eExitPuzzle.name = gameTriggerEventName.exit_puzzle;
        app.triggerMgr.fire(eExitPuzzle);
    }

    private _onEvent_EnterPuzzle(e:TriggerEvent) {
        this._enterPuzzleScene();
        return true;
    }

    private async _enterPuzzleScene() {
        app.viewMgr.showTransparentMaskView(true);
        await app.viewMgr.exitScene();
        
        app.viewMgr.enterScene();
        app.viewMgr.showTransparentMaskView(false);
        
        await app.resMgr.loadRes(levelConfigPath+1);
        let levelConfig = app.resMgr.getRes(levelConfigPath+1).json;

        let e = new TriggerEvent();
        e.name = gameTriggerEventName.start_puzzle;
        e.data = levelConfig;
        app.triggerMgr.fire(e);
    }
}
