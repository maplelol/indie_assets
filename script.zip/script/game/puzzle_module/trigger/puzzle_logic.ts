
import { TriggerBase } from "../../../core/trigger/trigger_base";
import { TriggerEvent } from "../../../core/trigger/trigger_event";
import { app } from "../../../core/app";
import { gameTriggerEventName } from "../../base/model/trigger_def";
import { gameConfigName } from "../../base/model/config_def";
import { PuzzleModel } from "../model/puzzle_model";
import PuzzleMainUI from "../view/puzzle_main_ui";
import { PuzzlePieceFactory } from "../model/puzzle_piece_factory";
import { PuzzleTile } from "../model/puzzle_tile";
import { PuzzlePieceLayer } from "../model/puzzle_piece_layer";
import { kPuzzleTileType, puzzleHandCount, puzzleHandCids, kPuzzleHandPieceType } from "../model/puzzle_def";
import PuzzleBoardView from "../view/puzzle_board_view";
import { kViewLayers } from "../../../core/view/view_manager";
import { PuzzlePiece } from "../model/puzzle_piece";
import { RandomUtil } from "../../../core/random_util";
import PuzzleMainUIHand from "../view/puzzle_main_ui_hand";
import EmptyView from "../../base/view/empty_view";
import { PuzzleDragPreviewOffsetY, kTileStandardPixelSize } from "../view/puzzle_view_def";

export default class TriggerPuzzleLogic extends TriggerBase {
    private _puzzleModel:PuzzleModel = undefined;
    /** 棋盘特效层 */
    private _puzzleBoardView:PuzzleBoardView = undefined;
    /** 棋盘特效层 */
    private _nodeEffectLayer:cc.Node = undefined;
    /** 拖拽预览 */
    private _nodeDragPreview:cc.Node = undefined;

    constructor() {
        super([
            gameTriggerEventName.start_puzzle,
            gameTriggerEventName.puzzle_drag_hand_began,
            gameTriggerEventName.puzzle_drag_hand_moved,
            gameTriggerEventName.puzzle_drag_hand_ended,
        ]);
    }

    onEvent(e:TriggerEvent) {
        if (e.name == gameTriggerEventName.start_puzzle) {
            return this._onEvent_StartPuzzle(e);
        } else if (e.name == gameTriggerEventName.puzzle_drag_hand_began) {
            return this._onEvent_PuzzleDragHandBegan(e);
        } else if (e.name == gameTriggerEventName.puzzle_drag_hand_moved) {
            return this._onEvent_PuzzleDragHandMoved(e);
        } else if (e.name == gameTriggerEventName.puzzle_drag_hand_ended) {
            return this._onEvent_PuzzleDragHandEnded(e);
        }
    }

    private _onEvent_StartPuzzle(e:TriggerEvent) {
        this._startPuzzle(e.data);
        return true;
    }

    private async _startPuzzle(levelConfig:any) {
        this._puzzleModel = this._setupModel(levelConfig);
        this._setupView(this._puzzleModel);
    }

    private _setupModel(levelConfig:any) {
        let puzzleModel = new PuzzleModel();
        puzzleModel.width = levelConfig.width;
        puzzleModel.height = levelConfig.height;

        /** 过关目标 */
        levelConfig.goals.forEach(g => {
            puzzleModel.goals.push({cid:g.cid,count:g.count,progress:0});
        });

        /** 初始化地形 */
        for (let i=0;i <levelConfig.tiles.length; ++i) {
            let pos = puzzleModel.i2t(i);
            if (pos[0] >= puzzleModel.width || pos[1] >= puzzleModel.height) {
                continue;
            }
            let newTile = new PuzzleTile();
            newTile.uid = puzzleModel.allocId();
            newTile.type = levelConfig.tiles[i];
            newTile.tileX = pos[0];
            newTile.tileY = pos[1];
            puzzleModel.tiles[i] = newTile;
            
            let newLayer = new PuzzlePieceLayer();
            puzzleModel.piece_layers[i] = newLayer;
        }

        /** 初始化物件 */
        for (let i=0; i<levelConfig.pieces.length; ++i) {
            let one = levelConfig.pieces[i];

            if (one.tile[0] < 0 || one.tile[0] >= puzzleModel.width
                || one.tile[1] < 0 || one.tile[1] >= puzzleModel.height
                || puzzleModel.tiles[puzzleModel.t2i(one.tile[0],one.tile[1])].type != kPuzzleTileType.fill) {
                console.warn("TriggerPuzzleLogic:_setupModel:try to spawn a piece on invalid tile:"+one.tile[0]+":"+one.tile[1]);
                continue;
            }
            
            let pieceConfig = app.configMgr.getConfig(gameConfigName.piece,one.cid);
            let newPiece = PuzzlePieceFactory.createPiece(puzzleModel.allocId(),pieceConfig,one);
            newPiece.tileX = one.tile[0];
            newPiece.tileY = one.tile[1];
            puzzleModel.addPiece(newPiece);
        }

        /** 初始化手牌 */
        for (let i=0; i<puzzleHandCount; ++i) {
            let cid = RandomUtil.random_from_array(puzzleHandCids);
            let pieceConfig = app.configMgr.getConfig(gameConfigName.piece,cid);
            let handType = RandomUtil.random(kPuzzleHandPieceType.dot1x1,kPuzzleHandPieceType.max-1);
            let handPiece = PuzzlePieceFactory.createHandPiece(puzzleModel.allocId(),pieceConfig,handType);
            puzzleModel.hand_pieces.push(handPiece);
        }

        return puzzleModel;
    }

    private async _setupView(puzzleModel:PuzzleModel) {
        await app.viewMgr.openMainUI(PuzzleMainUI.url,puzzleModel);

        let nodeBoard = new cc.Node();
        nodeBoard.name = "puzzle_board";
        nodeBoard.anchorX = 0.5;nodeBoard.anchorY = 0.5;
        nodeBoard.y += 40;
        this._puzzleBoardView = nodeBoard.addComponent(PuzzleBoardView);
        app.viewMgr.addView(this._puzzleBoardView,kViewLayers.bottom);

        // let sp = app.viewMgr.newFullScreenLayer("test");
        // let compSp = sp.addComponent(cc.Sprite);
        // compSp.spriteFrame = app.resMgr.getRes("texture/ui/gage_b_fill08",cc.SpriteFrame);
        // compSp.type = cc.Sprite.Type.SLICED;
        // nodeBoard.addChild(sp);
        
        this._puzzleBoardView.setup(puzzleModel.width,puzzleModel.height);
        this._puzzleBoardView.setTiles(puzzleModel);
        puzzleModel.piece_map.forEach((p:PuzzlePiece,uid)=>{
            this._puzzleBoardView.initSpawnPiece(p);
        });

        this._nodeEffectLayer = app.viewMgr.newFullScreenLayer("puzzle_board_effect");
        let compEffectView = this._nodeEffectLayer.addComponent(EmptyView);
        app.viewMgr.addView(compEffectView,kViewLayers.middle);
    }

    private _onEvent_PuzzleDragHandBegan(e:TriggerEvent) {
        console.log("TriggerPuzzleLogic:_onEvent_PuzzleDragHandBegan");
        let eTouch = e.data as cc.Event.EventTouch;
        let compHand = e.object as PuzzleMainUIHand;
        let handPiece = this._puzzleModel.hand_pieces[compHand.index];
        let nodeHandPiece = compHand.nodeHandPiece;
        this._nodeDragPreview = cc.instantiate(nodeHandPiece);
        this._nodeDragPreview.runAction(cc.scaleTo(0.2,1.05));

        let posWorld = nodeHandPiece.convertToWorldSpaceAR(cc.Vec2.ZERO);
        posWorld = this._nodeEffectLayer.convertToNodeSpaceAR(posWorld);
        this._nodeDragPreview.x = posWorld.x;
        this._nodeDragPreview.y = posWorld.y;// + handPiece.sizeY*kTileStandardPixelSize.height;
        this._nodeEffectLayer.addChild(this._nodeDragPreview);

        compHand.startDragPreview();
    }
    
    private _onEvent_PuzzleDragHandMoved(e:TriggerEvent) {
        let eTouch = e.data as cc.Event.EventTouch;
        let compHand = e.object as PuzzleMainUIHand;
        let handPiece = this._puzzleModel.hand_pieces[compHand.index];
        let posWorld = compHand.node.convertToNodeSpaceAR(eTouch.getLocation());
        posWorld = compHand.node.convertToWorldSpaceAR(posWorld);

        let posPreview = this._nodeEffectLayer.convertToNodeSpaceAR(posWorld);
        /** 设置x偏移到最左边 */
        this._nodeDragPreview.x = posPreview.x + handPiece.sizeX*0.5*kTileStandardPixelSize.width - 0.5*kTileStandardPixelSize.width;
        /** 设置y向上偏移一些，防止挡住手指 */
        this._nodeDragPreview.y = posPreview.y + handPiece.sizeY*kTileStandardPixelSize.height*0.85;

        let posBoardView = this._puzzleBoardView.node.convertToNodeSpaceAR(posWorld);
        /** y以最下面的位置算 */
        posBoardView.y -= (handPiece.sizeY*kTileStandardPixelSize.height*0.5 - 0.5*kTileStandardPixelSize.height);
        /** 然后再向上偏移一些，防止挡住手指 */
        posBoardView.y += handPiece.sizeY*kTileStandardPixelSize.height*0.85;
        let posTile = this._puzzleBoardView.p2t(posBoardView.x,posBoardView.y);
        if (posTile && posTile[0]+handPiece.sizeX-1<this._puzzleModel.width && posTile[1]+handPiece.sizeY-1<this._puzzleModel.height) {
            handPiece.tileX = posTile[0];
            handPiece.tileY = posTile[1];
            this._puzzleBoardView.enableDragPreivew(handPiece);
        } else {
            this._puzzleBoardView.disableDragPreview();
        }
    }
    
    private _onEvent_PuzzleDragHandEnded(e:TriggerEvent) {
        console.log("TriggerPuzzleLogic:_onEvent_PuzzleDragHandEnded");

        this._puzzleBoardView.disableDragPreview();

        let compHand = e.object as PuzzleMainUIHand;
        let nodeHandPiece = compHand.nodeHandPiece;
        let posWorld = nodeHandPiece.convertToWorldSpaceAR(cc.Vec2.ZERO);
        posWorld = this._nodeEffectLayer.convertToNodeSpaceAR(posWorld);
        let backDt = Math.min(0.3,Math.max(0.15,posWorld.sub(this._nodeDragPreview.position).mag()/2500));
        this._nodeDragPreview.runAction(cc.sequence(
            cc.spawn(cc.moveTo(backDt,posWorld),cc.scaleTo(backDt,nodeHandPiece.scale)),
            cc.callFunc(()=>{
                this._nodeDragPreview.destroy();
                this._nodeDragPreview = undefined;
                compHand.endDragPreview();
            })
        ));
    }
}
