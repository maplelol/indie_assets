
/** 标准棋盘大小 */
export const kPuzzleStandardBoardSize = {
    width : 8,
    height : 9,
}

/** 棋盘地形 */
export enum kPuzzleTileType {
    none, 
    fill, //可以放置物件
}

/** 坐标x,y */
export type PuzzleV2 = [number,number];

/** 过关目标 */
export type PuzzleGoal = {cid:number,count:number,progress:number};

/** 手牌数量 */
export const puzzleHandCount = 3;

/** 手牌类型 */
export enum kPuzzleHandPieceType {
    min,
    // 口
    dot1x1,

    // 口口
    line2x1,
    // 口口口
    line3x1,
    // 口口口口
    line4x1,
    // 口口口口口
    line5x1,

    // 口口
    // 口口
    dot2x2,
    // 口
    // 口口
    l2x2,

    //   口
    // 口口
    // 口
    z2x3,
    // 口
    // 口口
    // 口
    w2x3,

    // 口口口
    // 口口口
    // 口口口
    dot3x3,
    // 口
    // 口
    // 口口口
    l3x3,

    max,
}

/** 作为手牌的物件 */
export const puzzleHandCids = [1001,1002,1003,1004,1005];
