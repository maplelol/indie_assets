import { kPuzzleTileType } from "./puzzle_def";

/**
 * 棋盘地形
 * 占用1x1大小
 */
export class PuzzleTile {
    /** 实例id */
    uid:number = undefined;

    /** 位置 */
    tileX:number = undefined;
    tileY:number = undefined;

    /** 类型 */
    type:kPuzzleTileType = kPuzzleTileType.none;
}
