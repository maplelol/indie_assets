import { PuzzlePiece, PuzzleHandPiece } from "./puzzle_piece";
import { kPuzzleHandPieceType } from "./puzzle_def";

/**
 * 创建棋盘物件的工厂类
 */
export class PuzzlePieceFactory {
    private static _mapHandPieceDefault:Map<kPuzzleHandPieceType,PuzzleHandPiece> = new Map();

    static createPiece(uid:number,config:any,extra:any):PuzzlePiece {
        let newPiece = new PuzzlePiece();
        newPiece.uid = uid;
        newPiece.cid = config.cid;
        newPiece.sizeX = config.sizeX;
        newPiece.sizeY = config.sizeY;
        newPiece.colors = new Map();
        for (let c in config.colors) {
            newPiece.colors[c] = config.colors[c];
        }
        newPiece.hpMax = config.hp;
        newPiece.hpCur = newPiece.hpMax;
        newPiece.layer = config.layer;

        return newPiece;
    }

    static createHandPiece(uid:number,config:any,type:kPuzzleHandPieceType) {
        let handPiece = PuzzlePieceFactory._getDefaultHandPiece(type);
        handPiece = JSON.parse(JSON.stringify(handPiece));
        handPiece.uid = uid;
        handPiece.cid = config.cid;
        handPiece.colors = new Map();
        for (let c in config.colors) {
            handPiece.colors[c] = config.colors[c];
        }
        handPiece.layer = config.layer;

        return handPiece;
    }

    private static _getDefaultHandPiece(type:kPuzzleHandPieceType) {
        let ret = PuzzlePieceFactory._mapHandPieceDefault.get(type);
        if (!ret) {
            ret = new PuzzleHandPiece();
            PuzzlePieceFactory._mapHandPieceDefault.set(type,ret);
            ret.handType = type;
            switch(type) {
                case kPuzzleHandPieceType.dot1x1: {
                    ret.sizeX = 1;
                    ret.sizeY = 1;
                    ret.tiles = [true];
                } break;
                case kPuzzleHandPieceType.line2x1: {
                    ret.sizeX = 2;
                    ret.sizeY = 1;
                    ret.tiles = [true,true];
                } break;
                case kPuzzleHandPieceType.line3x1: {
                    ret.sizeX = 3;
                    ret.sizeY = 1;
                    ret.tiles = [true,true,true];
                } break;
                case kPuzzleHandPieceType.line4x1: {
                    ret.sizeX = 4;
                    ret.sizeY = 1;
                    ret.tiles = [true,true,true,true];
                } break;
                case kPuzzleHandPieceType.line5x1: {
                    ret.sizeX = 5;
                    ret.sizeY = 1;
                    ret.tiles = [true,true,true,true,true];
                } break;
                case kPuzzleHandPieceType.dot2x2: {
                    ret.sizeX = 2;
                    ret.sizeY = 2;
                    ret.tiles = [true,true,true,true];
                } break;
                case kPuzzleHandPieceType.l2x2: {
                    ret.sizeX = 2;
                    ret.sizeY = 2;
                    ret.tiles = [true,true,true,false];
                } break;
                case kPuzzleHandPieceType.z2x3: {
                    ret.sizeX = 2;
                    ret.sizeY = 2;
                    ret.tiles = [true,false,true,true,false,true];
                } break;
                case kPuzzleHandPieceType.w2x3: {
                    ret.sizeX = 2;
                    ret.sizeY = 3;
                    ret.tiles = [true,false,true,true,true,false];
                } break;
                case kPuzzleHandPieceType.dot3x3: {
                    ret.sizeX = 3;
                    ret.sizeY = 3;
                    ret.tiles = [true,true,true,true,true,true,true,true,true];
                } break;
                case kPuzzleHandPieceType.l3x3: {
                    ret.sizeX = 3;
                    ret.sizeY = 3;
                    ret.tiles = [true,true,true,true,false,false,true,false,false];
                } break;
                default: {
                    console.error("PuzzlePieceFactory:_getDefaultHandPiece:invalid type:"+type);
                }
            }
        }
        return ret;
    }
}
