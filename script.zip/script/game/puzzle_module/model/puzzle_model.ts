
import { PuzzlePiece, PuzzleHandPiece } from "./puzzle_piece";
import { PuzzleTile } from "./puzzle_tile";
import { PuzzleV2, kPuzzleTileType, PuzzleGoal } from "./puzzle_def";
import { PuzzlePieceLayer } from "./puzzle_piece_layer";

/**
 * 棋盘
 */
export class PuzzleModel {
    /** 大小 */
    width:number = undefined;
    height:number = undefined;

    /** 地形 */
    tiles:PuzzleTile[] = undefined;
    /** 物件层，每个层里面有多个物件 */
    piece_layers:PuzzlePieceLayer[] = undefined;
    /** 物件查找表 */
    piece_map:Map<number,PuzzlePiece> = undefined;

    /** 过关目标 */
    goals:PuzzleGoal[] = undefined;

    /** 手牌，就是屏幕底部玩家可以操作的三个砖块 */
    hand_pieces:PuzzleHandPiece[] = undefined;

    /** 分配实例id */
    private _iAllocId:number = 0;

    constructor() {
        this.tiles = [];
        this.piece_layers = [];
        this.piece_map = new Map();
        this.goals = [];
        this.hand_pieces = [];
    }

    allocId() {
        return ++this._iAllocId;
    }

    /**
     * 坐标和index的转换
     */
    t2i(tx:number,ty:number) {
        return ty*this.width + tx;
    }
    i2t(i:number):PuzzleV2 {
        let tx = i%this.width;
        let ty = Math.floor(i/this.width);
        return [tx,ty];
    }

    /** 添加物件 */
    addPiece(piece:PuzzlePiece) {
        this.piece_map.set(piece.uid,piece);
        this.piece_layers[this.t2i(piece.tileX,piece.tileY)].addPiece(piece);
    }
    /** 删除物件 */
    removePiece(uid:number) {
        let piece = this.getPiece(uid);
        this.piece_map.delete(uid);
        this.piece_layers[this.t2i(piece.tileX,piece.tileY)].removePiece(uid);
    }
    /** 查找物件 */
    getPiece(uid:number) {
        return this.piece_map.get(uid);
    }
}
