import { kPuzzleHandPieceType } from "./puzzle_def";

/**
 * 棋盘物件
 */
export class PuzzlePiece {
    /** 实例id */
    uid:number = undefined;
    /** 配置id */
    cid:number = undefined;

    /** 位置，左下角 */
    tileX:number = undefined;
    tileY:number = undefined;

    /** 大小 */
    sizeX:number = undefined;
    sizeY:number = undefined;

    /** 占用的所有地块
     * 相对于左下角原点
     * 先遍历x，再遍历y
     * 假设sizeX=sizeY=2，那么
     * tiles[0]=true，表示这个物件的[0,0]有占用
     * tiles[2]=false，表示这个物件的[0,1]没有占用
     */
    tiles:boolean[] = undefined;
    
    /**
     * 一个物件可能包含多种颜色
     * k=colorValue
     * v=colorCount
     * colorCount的总和应该等于hpMax
     */
    colors:Map<number,number> = undefined;
    
    /**
     * 生命，表示需要消除的次数
     * 如果hpMax=-1，表示这个物件不会被消除
     */
    hpCur:number = 0;
    hpMax:number = 0;

    /** 所在的层级 */
    layer:number = 0;
}

/** 手牌物件 */
export class PuzzleHandPiece extends PuzzlePiece {
    handType:kPuzzleHandPieceType = undefined;

    /**
     * 顺时针旋转
     * @param degree 90|180|270
     */
    rotate(degree:number) {

    }
}
