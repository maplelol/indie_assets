import { PuzzlePiece } from "./puzzle_piece";

/**
 * 物件层，每一个地块上可能会有多层物件
 */
export class PuzzlePieceLayer {
    /**
     * k=layerValue，遍历的时候从大往小，也就是这个值越大，逻辑优先级越高
     */
    private _layers:Map<number,PuzzlePiece> = undefined;

    /** 是否需要重排序key */
    private _dirty:boolean = true;
    /** 排好序的key */
    private _sortedKeys:number[] = undefined;

    constructor() {
        this._layers = new Map();
    }

    addPiece(piece:PuzzlePiece) {
        if (this._layers.get(piece.layer)) {
            console.warn("PuzzlePieceLayer:duplicate pieces on same layer:"+piece.cid);
        } else {
            this._layers.set(piece.layer,piece);
            this._dirty = true;
        }
    }

    removePiece(layer:number) {
        this._layers.delete(layer);
        this._dirty = true;
    }

    /** 按layer从大到小的顺序遍历 */
    foreachPiece(fn:Function) {
        if (this._dirty) {
            this._dirty = false;
            this._sortedKeys = Array.from(this._layers.keys());
            this._sortedKeys.sort();
        }
        for (let i=this._sortedKeys.length-1; i>=0; --i) {
            fn(this._layers.get(this._sortedKeys[i]));
        }
    }
}
