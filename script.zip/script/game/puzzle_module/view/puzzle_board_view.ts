import { ViewBase } from "../../../core/view/view_base";
import { kPuzzleStandardBoardSize, kPuzzleTileType, PuzzleV2 } from "../model/puzzle_def";
import { PuzzleTile } from "../model/puzzle_tile";
import { app } from "../../../core/app";
import { PuzzleModel } from "../model/puzzle_model";
import { PuzzlePiece, PuzzleHandPiece } from "../model/puzzle_piece";
import { kTileStandardPixelSize, kTileSpace } from "./puzzle_view_def";
import { PuzzlePieceViewFactory } from "./puzzle_piece_view_factory";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/puzzle_module/view/PuzzleBoardView")
export default class PuzzleBoardView extends ViewBase {

    /** 地形层 */
    private _nodeTileLayer:cc.Node = undefined;
    /** 物件层 */
    private _nodePieceLayer:cc.Node = undefined;
    /** 拖放时的预览层 */
    private _nodeDragPreviewLayer:cc.Node = undefined;

    /** 像素和地块的转换 */
    p2t(px:number,py:number):PuzzleV2 {
        px += this.node.width*0.5;
        py += this.node.height*0.5;
        
        if (px < 0 || px > this.node.width || py < 0 || py > this.node.height) {
            return undefined;
        }

        return [Math.floor(px/kTileStandardPixelSize.width),Math.floor(py/kTileStandardPixelSize.height)];
    }

    /** 设置大小，以地块为单位 */
    setup(width:number,height:number) {
        this.node.width = width*kTileStandardPixelSize.width + (kPuzzleStandardBoardSize.width-1)*kTileSpace.x;
        this.node.height = height*kTileStandardPixelSize.height + (kPuzzleStandardBoardSize.height-1)*kTileSpace.y;

        let scaleX = kPuzzleStandardBoardSize.width/width;
        let scaleY = kPuzzleStandardBoardSize.height/height;
        this.node.scale = Math.min(scaleX,scaleY);

        this._nodeTileLayer = app.viewMgr.newFullScreenLayer("tile_layer");
        this.node.addChild(this._nodeTileLayer);
        this._nodePieceLayer = app.viewMgr.newFullScreenLayer("piece_layer");
        this.node.addChild(this._nodePieceLayer);
        this._nodeDragPreviewLayer = app.viewMgr.newFullScreenLayer("drag_preview_layer");
        this.node.addChild(this._nodeDragPreviewLayer);
    }

    /** 设置地形 */
    setTiles(puzzleModel:PuzzleModel) {
        let t:PuzzleTile = undefined;
        let deltaX = -this.node.width*0.5 + kTileStandardPixelSize.width*0.5;
        let deltaY = -this.node.height*0.5 + kTileStandardPixelSize.height*0.5;
        for (let i=0; i<puzzleModel.tiles.length; ++i) {
            t = puzzleModel.tiles[i];
            if (t.type != kPuzzleTileType.fill) {
                continue;
            }

            let nodeTile = new cc.Node();
            nodeTile.anchorX = nodeTile.anchorY = 0.5;
            nodeTile.width = kTileStandardPixelSize.width;
            nodeTile.height = kTileStandardPixelSize.height;
            nodeTile.name = "tile_"+t.tileX+"_"+t.tileY;
            nodeTile.x = t.tileX*kTileStandardPixelSize.width + (t.tileX-1)*kTileSpace.x + deltaX;
            nodeTile.y = t.tileY*kTileStandardPixelSize.height + (t.tileY-1)*kTileSpace.y + deltaY;

            let spTile = nodeTile.addComponent(cc.Sprite);
            spTile.type = cc.Sprite.Type.SLICED;
            spTile.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            spTile.trim = true;
            /** 必须放在最后设置，不然上面的那三行不会生效…… */
            spTile.spriteFrame = app.resMgr.getRes("texture/ui/checkbox_blank",cc.SpriteFrame);

            this._nodeTileLayer.addChild(nodeTile);
        }
    }

    /** 生成初始物件 */
    initSpawnPiece(piece:PuzzlePiece) {
        let deltaX = -this.node.width*0.5 + kTileStandardPixelSize.width*0.5;
        let deltaY = -this.node.height*0.5 + kTileStandardPixelSize.height*0.5;
        
        let nodePiece = PuzzlePieceViewFactory.createPiece(piece);
        nodePiece.name = "piece_"+piece.layer+"_"+piece.tileX+"_"+piece.tileY;
        nodePiece.x = piece.tileX*kTileStandardPixelSize.width + piece.tileX*kTileSpace.x + deltaX;
        nodePiece.y = piece.tileY*kTileStandardPixelSize.height + piece.tileY*kTileSpace.y + deltaY;
        
        this._nodePieceLayer.addChild(nodePiece);
    }

    /** 拖拽在棋盘上的预览 */
    enableDragPreivew(handPiece:PuzzleHandPiece) {
        this._nodeDragPreviewLayer.destroyAllChildren();

        let deltaX = -this.node.width*0.5 + kTileStandardPixelSize.width*0.5;
        let deltaY = -this.node.height*0.5 + kTileStandardPixelSize.height*0.5;

        let tx = handPiece.tileX;
        let ty = handPiece.tileY;
        for (let h=0; h<handPiece.sizeY; ++h) {
            for (let w=0; w<handPiece.sizeX; ++w) {
                let i = h*handPiece.sizeX + w;
                if (handPiece.tiles[i]) {
                    handPiece.tileX = tx + w;
                    handPiece.tileY = ty + h;
                    let nodePiece = PuzzlePieceViewFactory.createPiece(handPiece);
                    nodePiece.x = handPiece.tileX*kTileStandardPixelSize.width + handPiece.tileX*kTileSpace.x + deltaX;
                    nodePiece.y = handPiece.tileY*kTileStandardPixelSize.height + handPiece.tileY*kTileSpace.y + deltaY;
                    nodePiece.opacity = 150;
                    this._nodeDragPreviewLayer.addChild(nodePiece);
                }
            }
        }

        /** 还原数值 */
        handPiece.tileX = tx;
        handPiece.tileY = ty;
    }

    disableDragPreview() {
        this._nodeDragPreviewLayer.destroyAllChildren();
    }

    
    protected willOpen() {
    }
    protected onOpened() {
    }
    protected willClose() {
    }
    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start () {}

    // update (dt) {}
}
