
/** 棋盘地块标准大小，单位像素 */
export const kTileStandardPixelSize = {
    width : 85,
    height : 98,
}

/** 棋盘地块之间间隔，单位像素 */
export const kTileSpace = {
    x : 3,
    y : 3,
}

/** 拖拽预览向上偏移的像素 */
export const PuzzleDragPreviewOffsetY = 150;
