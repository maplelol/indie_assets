import { ViewBase } from "../../../core/view/view_base";
import { PuzzleModel } from "../model/puzzle_model";
import PuzzleMainUIGoal from "./puzzle_main_ui_goal";
import PuzzleMainUIHand from "./puzzle_main_ui_hand";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/puzzle_module/view/PuzzleMainUI")
export default class PuzzleMainUI extends ViewBase {
    static url:string = "view/puzzle_main/puzzle_main";

    @property(cc.Node)
    btnExit:cc.Node = undefined;
    @property([cc.Node])
    nodeGoalList:cc.Node[] = [];
    @property([cc.Node])
    nodeHandList:cc.Node[] = [];

    protected willOpen() {
        let puzzleModel:PuzzleModel = this._openParams[0];

        /** 关卡目标 */
        for (let i=0; i<this.nodeGoalList.length; ++i) {
            let compGoal = this.nodeGoalList[i].getComponent(PuzzleMainUIGoal);
            compGoal.setItem(puzzleModel.goals[i]);
        }

        /** 手牌 */
        for (let i=0; i<this.nodeHandList.length; ++i) {
            let compHand = this.nodeHandList[i].getComponent(PuzzleMainUIHand);
            compHand.index = i;
            compHand.setPiece(puzzleModel.hand_pieces[i]);
        }

        this.node.getComponent(cc.Animation).play("open");
        return new Promise((resolve,reject)=>{
            this.node.getComponent(cc.Animation).on("finished",()=>{
                resolve();
            });
        });
    }
    protected onOpened() {
    }
    protected willClose() {
    }
    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this._bindFireClickBtn(this.btnExit);
    }

    // start () {}

    // update (dt) {}
}
