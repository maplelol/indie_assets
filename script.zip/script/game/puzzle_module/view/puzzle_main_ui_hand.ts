import { PuzzleGoal } from "../model/puzzle_def";
import { app } from "../../../core/app";
import { gameConfigName } from "../../base/model/config_def";
import { res_path_puzzle_piece_texture } from "../../base/view/res_def";
import { PuzzleHandPiece } from "../model/puzzle_piece";
import { TriggerEvent } from "../../../core/trigger/trigger_event";
import { gameTriggerEventName } from "../../base/model/trigger_def";
import { PuzzlePieceViewFactory } from "./puzzle_piece_view_factory";
import { kTileStandardPixelSize } from "./puzzle_view_def";

enum kState {
    empty, //没有手牌
    filled, //有手牌
    using, //拖拽中
    used_success, //放下了
    used_failed, //放下了，但没成功
}

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/puzzle_module/view/PuzzleMainUIHand")
export default class PuzzleMainUIHand extends cc.Component {
    /**
     * 当前的显示状态
     */
    private _state:kState = kState.empty;

    /**
     * 位置
     */
    private _index:number = undefined;
    
    set index(i:number) {
        this._index = i;
    }
    get index() {
        return this._index;
    }

    get nodeHandPiece() {
        return this.node.children[0];
    }

    setPiece(piece:PuzzleHandPiece) {
        let nodeHandPiece = PuzzlePieceViewFactory.createHandPiece(piece);
        this.node.addChild(nodeHandPiece);
        
        /** 按最小的比例缩放 */
        let scaleX = this.node.width/(piece.sizeX*nodeHandPiece.children[0].width);
        let scaleY = this.node.height/(piece.sizeY*nodeHandPiece.children[0].height);
        nodeHandPiece.scale = Math.min(scaleX,scaleY,1);
    }

    startDragPreview() {
        this.nodeHandPiece.active = false;
    }
    endDragPreview() {
        this.nodeHandPiece.active = true;
    }

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.node.on(cc.Node.EventType.TOUCH_START,(e:cc.Event.EventTouch)=>{
            this._fireTouch(e,gameTriggerEventName.puzzle_drag_hand_began);});
        this.node.on(cc.Node.EventType.TOUCH_MOVE,(e:cc.Event.EventTouch)=>{
            this._fireTouch(e,gameTriggerEventName.puzzle_drag_hand_moved);});
        this.node.on(cc.Node.EventType.TOUCH_END,(e:cc.Event.EventTouch)=>{
            this._fireTouch(e,gameTriggerEventName.puzzle_drag_hand_ended);});
        this.node.on(cc.Node.EventType.TOUCH_CANCEL,(e:cc.Event.EventTouch)=>{
            this._fireTouch(e,gameTriggerEventName.puzzle_drag_hand_ended);});
    }

    // start () {}

    // update (dt) {}

    private _fireTouch(e:cc.Event.EventTouch,eName:string) {
        if (!this.nodeHandPiece) {
            return;
        }

        let eDrag = new TriggerEvent();
        eDrag.name = eName;
        eDrag.data = e;
        eDrag.object = this;
        app.triggerMgr.fire(eDrag);
    }
}
