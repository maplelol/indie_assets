import { PuzzleGoal } from "../model/puzzle_def";
import { app } from "../../../core/app";
import { gameConfigName } from "../../base/model/config_def";
import { res_path_puzzle_piece_texture } from "../../base/view/res_def";

enum kState {
    empty, //没有目标物
    filled, //有目标物
    collecting, //被收集了
    complete, //收集完成了
}

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/puzzle_module/view/PuzzleMainUIGoal")
export default class PuzzleMainUIGoal extends cc.Component {
    @property(cc.Node)
    spItemIcon:cc.Node = undefined;
    @property(cc.Node)
    lblCount:cc.Node = undefined;

    /**
     * 当前的显示状态
     */
    private _state:kState = kState.empty;

    setItem(goal:PuzzleGoal) {
        if (goal) {
            this._state = kState.filled;
            this.spItemIcon.active = true;
            this.spItemIcon.getComponent(cc.Sprite).spriteFrame = app.resMgr.getRes(res_path_puzzle_piece_texture+goal.cid,cc.SpriteFrame);
            this.lblCount.active = true;
            this.lblCount.getComponent(cc.Label).string = goal.progress+"/"+goal.count;
        } else {
            this._state = kState.empty;
            this.spItemIcon.active = false;
            this.lblCount.active = false;
        }
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start () {}

    // update (dt) {}
}
