import { ViewBase } from "../../../core/view/view_base";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/puzzle_module/view/PuzzleExitUI")
export default class PuzzleExitUI extends ViewBase {
    static url:string = "view/puzzle_exit/puzzle_exit";

    @property(cc.Node)
    btnExit:cc.Node = undefined;
    @property(cc.Node)
    btnRestart:cc.Node = undefined;
    @property(cc.Node)
    btnContinue:cc.Node = undefined;
    @property(cc.Node)
    btnClose:cc.Node = undefined;

    protected willOpen() {
        this.node.getComponent(cc.Animation).play("open");
        return new Promise((resolve,reject)=>{
            this.node.getComponent(cc.Animation).on("finished",()=>{
                resolve();
            });
        });
    }
    protected onOpened() {
    }
    protected willClose() {
        this.node.getComponent(cc.Animation).play("close");
        return new Promise((resolve,reject)=>{
            this.node.getComponent(cc.Animation).on("finished",()=>{
                resolve();
            });
        });
    }
    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this._bindFireClickBtn(this.btnExit);
        this._bindFireClickBtn(this.btnRestart);
        this._bindFireClickBtn(this.btnContinue);
        this._bindFireClickBtn(this.btnClose);
    }

    // start () {}

    // update (dt) {}
}
