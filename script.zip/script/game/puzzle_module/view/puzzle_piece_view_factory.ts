import { PuzzlePiece, PuzzleHandPiece } from "../model/puzzle_piece";
import { app } from "../../../core/app";
import { gameConfigName } from "../../base/model/config_def";
import { res_path_puzzle_piece_texture } from "../../base/view/res_def";
import { kTileStandardPixelSize } from "./puzzle_view_def";

export class PuzzlePieceViewFactory {
    static createPiece(piece:PuzzlePiece) {
        let nodePiece = new cc.Node();
        nodePiece.anchorX = nodePiece.anchorY = 0.5;
        
        let spTile = nodePiece.addComponent(cc.Sprite);
        spTile.type = cc.Sprite.Type.SIMPLE;
        spTile.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        spTile.trim = true;
        /** 必须放在最后设置，不然上面的那三行不会生效…… */
        spTile.spriteFrame = app.resMgr.getRes(res_path_puzzle_piece_texture+piece.cid,cc.SpriteFrame);
        
        /** 按比例设置一下长宽 */
        let scale = kTileStandardPixelSize.width/spTile.spriteFrame.getOriginalSize().width;
        nodePiece.width = kTileStandardPixelSize.width;
        nodePiece.height = spTile.spriteFrame.getOriginalSize().height*scale;
        
        return nodePiece;
    }

    static createHandPiece(handPiece:PuzzleHandPiece) {
        let nodeHandPiece = new cc.Node();
        let deltaX = -kTileStandardPixelSize.width*0.5*handPiece.sizeX + kTileStandardPixelSize.width*0.5;
        let deltaY = -kTileStandardPixelSize.height*0.5*handPiece.sizeY + kTileStandardPixelSize.height*0.5;
        for (let h=0; h<handPiece.sizeY; ++h) {
            for (let w=0; w<handPiece.sizeX; ++w) {
                let i = h*handPiece.sizeX + w;
                if (handPiece.tiles[i]) {
                    let nodePiece = this.createPiece(handPiece);
                    nodePiece.x = w*nodePiece.width + deltaX;
                    nodePiece.y = h*nodePiece.height + deltaY;
                    nodeHandPiece.addChild(nodePiece);
                }
            }
        }
        return nodeHandPiece;
    }
}
