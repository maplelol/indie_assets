
export const gameConfigName = {
    piece : "piece",
    level : "level",
}

export const levelConfigPath = "config/puzzle_level/level";
