
export const gameTriggerEventName = {
    splash_over : "splash_over",

    enter_puzzle : "enter_puzzle",
    exit_puzzle : "exit_puzzle",

    start_puzzle : "start_puzzle",
    puzzle_drag_hand_began : "puzzle_drag_hand_began",
    puzzle_drag_hand_moved : "puzzle_drag_hand_moved",
    puzzle_drag_hand_ended : "puzzle_drag_hand_ended",
}
