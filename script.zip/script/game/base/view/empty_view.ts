
import { ViewBase } from "../../../core/view/view_base";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/base/view/EmptyView")
export default class EmptyView extends ViewBase {
    protected willOpen() {
    }
    protected willClose() {
    }
    protected onOpened() {
    }
    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start () {}

    // update (dt) {}
}
