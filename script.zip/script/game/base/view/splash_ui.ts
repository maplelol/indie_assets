import { ViewBase } from "../../../core/view/view_base";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/base/view/SplashUI")
export default class SplashUI extends ViewBase {
    static url:string = "view/splash/splash";

    @property(cc.Node)
    barLoding:cc.Node = undefined;
    @property(cc.Node)
    lblLoading:cc.Node = undefined;

    private _nCurProgress:number = 0;
    private _nNextProgress:number = undefined;
    private _fnProgressOver:Function = undefined;

    /**
     * 设置进度显示
     * @param p a number value between 0~1
     */
    setProgress(p:number) {
        this._nNextProgress = p;
    }
    
    /**
     * 在进度条走到100%后会进行回调
     * @param fn 回调方法
     */
    onProgressOver(fn:Function) {
        this._fnProgressOver = fn;
    }

    protected async willOpen() {
        this._refreshProgress();

        this.node.getComponent(cc.Animation).play("open");
        return new Promise((resolve,reject)=>{
            this.node.getComponent(cc.Animation).on("finished",()=>{
                resolve();
            });
        });
    }
    protected onOpened() {
    }
    protected async willClose() {
        return new Promise((resolve,reject)=>{
            this.node.runAction(cc.sequence(
                cc.fadeOut(0.5),
                cc.delayTime(0.2),
                cc.callFunc(()=>{resolve()}),
            ))
        });
    }
    protected onClosed() {
    }

    private _refreshProgress() {
        this.lblLoading.getComponent(cc.Label).string = Math.floor(this._nCurProgress*100) + "%";
        this.barLoding.getComponent(cc.ProgressBar).progress = this._nCurProgress;
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    // start () {}

    update (dt) {
        if (this._nNextProgress != undefined && this._nNextProgress > this._nCurProgress) {
            let iNext = Math.floor(100*this._nNextProgress);
            let iCur = Math.floor(100*this._nCurProgress);
            if (iNext > iCur) {
                this._nCurProgress += 0.01;
                this._refreshProgress();
            }

            if (this._nCurProgress >= 1) {
                this._nNextProgress = undefined;

                /** 稍微等一会，视觉上会好一些 */
                this.scheduleOnce(()=>{
                    this._fnProgressOver && this._fnProgressOver();
                },0.3);
            }
        }
    }
}
