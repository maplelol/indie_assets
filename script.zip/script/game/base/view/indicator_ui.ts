import MaskViewBase from "../../../core/view/mask_view_base";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/base/view/IndicatorUI")
export default class IndicatorUI extends MaskViewBase {
    static url:string = "view/indicator/indicator";

    protected onOpened() {
        this.getComponent(cc.Animation).play("idle");
    }

    protected onClosed() {
        this.getComponent(cc.Animation).stop();
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {

    }

    // update (dt) {}
}
