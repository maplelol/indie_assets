
export const res_path_puzzle_piece_texture = "texture/piece/piece_";
