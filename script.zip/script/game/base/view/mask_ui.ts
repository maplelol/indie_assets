import MaskViewBase from "../../../core/view/mask_view_base";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/base/view/MaskUI")
export default class MaskUI extends MaskViewBase {
    static url:string = "view/indicator/mask";

    protected onOpened() {
    }

    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {

    }

    // update (dt) {}
}
