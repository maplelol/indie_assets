
import { TriggerBase } from "../../../core/trigger/trigger_base";
import { defaultTriggerEventName } from "../../../core/trigger/trigger_const";
import { TriggerEvent } from "../../../core/trigger/trigger_event";
import { app } from "../../../core/app";
import SplashUI from "../view/splash_ui";
import IndicatorUI from "../view/indicator_ui";
import MaskUI from "../view/mask_ui";
import { gameTriggerEventName } from "../model/trigger_def";
import { gameConfigName } from "../model/config_def";

export default class TriggerGameLaunched extends TriggerBase {
    constructor() {
        super([defaultTriggerEventName.game_launched]);
    }

    onEvent(e:TriggerEvent) {
        if (e.name == defaultTriggerEventName.game_launched) {
            this._onEvent_GameLaunched(e);
            return true;
        }
        return false;
    }

    async _onEvent_GameLaunched(e:TriggerEvent) {
        await app.resMgr.loadRes(IndicatorUI.url);
        await app.resMgr.loadRes(MaskUI.url);

        let nodeIndicator:cc.Node = cc.instantiate(app.resMgr.getRes(IndicatorUI.url));
        let nodeMask:cc.Node = cc.instantiate(app.resMgr.getRes(MaskUI.url));
        app.viewMgr.setup(nodeIndicator,nodeMask);
        app.viewMgr.openMainUI(SplashUI.url).then((view:SplashUI)=>{
            this._startLoad(view);
        });
    }

    async _startLoad(view:SplashUI) {
        view.onProgressOver(()=>{
            this._onLoadingProgressOver();
        });

        let vPreLoad = [
            {type:"dir",path:"texture/ui"},
            {type:"dir",path:"texture/piece"},
            {type:"json",path:"config/piece",name:gameConfigName.piece},
        ];
        let totalGroup = vPreLoad.length;
        for (let i=0; i<vPreLoad.length; ++i) {
            let pre = vPreLoad[i];
            if (pre.type == "dir") {
                await app.resMgr.loadResDir(pre.path,(completeCount:number,totalCount:number,item:any)=>{
                    view.setProgress(completeCount/totalCount/totalGroup + i/totalGroup);
                });
            } else if (pre.type == "atlas") {
                await app.resMgr.loadResAtlas(pre.path,(completeCount:number,totalCount:number,item:any)=>{
                    view.setProgress(completeCount/totalCount/totalGroup + i/totalGroup);
                });
            } else {
                await app.resMgr.loadRes(pre.path,(completeCount:number,totalCount:number,item:any)=>{
                    view.setProgress(completeCount/totalCount/totalGroup + i/totalGroup);
                });

                /** 添加配置查找表 */
                if (pre.type == "json") {
                    app.configMgr.addConfig(pre.name,cc.loader.getRes(pre.path).json);
                }
            }
        }
    }

    async _onLoadingProgressOver() {
        let e = new TriggerEvent();
        e.name = gameTriggerEventName.splash_over;
        app.triggerMgr.fire(e);
    }
}
