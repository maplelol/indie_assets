import { ViewBase } from "../../../core/view/view_base";

const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/hall_module/view/HallMainUI")
export default class HallMainUI extends ViewBase {
    static url:string = "view/hall_main/hall_main";

    @property(cc.Node)
    btnPlay:cc.Node = undefined;

    playBtnPlayIdle() {
        this.btnPlay.getComponent(cc.Animation).play("btn_play_idle");
    }

    protected async willOpen() {
        this.node.getComponent(cc.Animation).play("open");
        return new Promise((resolve,reject)=>{
            this.node.getComponent(cc.Animation).on("finished",()=>{
                resolve();
            });
        });
    }
    protected async onOpened() {
        this.playBtnPlayIdle();
    }
    protected willClose() {
        return new Promise((resolve,reject)=>{
            this.node.runAction(cc.sequence(
                cc.fadeOut(0.5),
                cc.delayTime(0.2),
                cc.callFunc(()=>{resolve()}),
            ))
        });
    }
    protected onClosed() {
    }

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this._bindFireClickBtn(this.btnPlay);
    }

    // start () {}

    // update (dt) {}
}
