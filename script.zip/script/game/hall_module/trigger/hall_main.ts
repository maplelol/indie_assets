
import { TriggerBase } from "../../../core/trigger/trigger_base";
import { defaultTriggerEventName } from "../../../core/trigger/trigger_const";
import { TriggerEvent } from "../../../core/trigger/trigger_event";
import { app } from "../../../core/app";
import HallMainUI from "../view/hall_main_ui";
import { gameTriggerEventName } from "../../base/model/trigger_def";

export default class TriggerHallMain extends TriggerBase {
    constructor() {
        super([
            defaultTriggerEventName.ui_btn_clicked,
            gameTriggerEventName.splash_over,
            gameTriggerEventName.exit_puzzle,
        ]);
    }

    onEvent(e:TriggerEvent) {
        if (e.name == defaultTriggerEventName.ui_btn_clicked) {
            if (e.object instanceof HallMainUI) {
                return this._onEvent_BtnClick_HallMainUI(e);
            }
        } else if (e.name == gameTriggerEventName.splash_over) {
            return this._onEvent_SplashOver(e);
        } else if (e.name == gameTriggerEventName.exit_puzzle) {
            return this._onEvent_ExitPuzzle(e);
        }
        return false;
    }

    private _onEvent_SplashOver(e:TriggerEvent) {
        this._enterHallScene();
        return true;
    }

    private async _enterHallScene() {
        await app.viewMgr.exitScene();
        app.viewMgr.openMainUI(HallMainUI.url);
        app.viewMgr.enterScene();
    }

    private _onEvent_BtnClick_HallMainUI(e:TriggerEvent) {
        let hallMainUI = e.object as HallMainUI;
        if (e.data == hallMainUI.btnPlay) {
            let eEnterPuzzle = new TriggerEvent();
            eEnterPuzzle.name = gameTriggerEventName.enter_puzzle;
            app.triggerMgr.fire(eEnterPuzzle);
            return true;
        }

        return false;
    }

    private _onEvent_ExitPuzzle(e:TriggerEvent) {
        this._enterHallScene();
        return true;
    }
}
