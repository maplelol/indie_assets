
import { app } from "../core/app";
import { TriggerEvent } from "../core/trigger/trigger_event";
import { defaultTriggerEventName } from "../core/trigger/trigger_const";

import TriggerGameLaunched from "./base/trigger/game_launched";
import TriggerHallMain from "./hall_module/trigger/hall_main";
import TriggerPuzzleMain from "./puzzle_module/trigger/puzzle_main";
import TriggerPuzzleLogic from "./puzzle_module/trigger/puzzle_logic";


const {ccclass, property, menu} = cc._decorator;

@ccclass
@menu("game/Launch")
export default class Launch extends cc.Component {

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        app.triggerMgr.regist(new TriggerGameLaunched());
        app.triggerMgr.regist(new TriggerHallMain());
        app.triggerMgr.regist(new TriggerPuzzleMain());
        app.triggerMgr.regist(new TriggerPuzzleLogic());
    }

    start () {
        let e = new TriggerEvent();
        e.name = defaultTriggerEventName.game_launched;
        e.object = this;
        app.triggerMgr.fire(e);
    }

    // update (dt) {}
}
